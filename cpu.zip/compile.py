def read_assembly():
    """Reads each line as an individual instruction from assembly.txt and returns them in an array"""


def compile_asm(instructions):
    """Takes an array of instructions and outputs image file (one for instruction_mem and one for data_mem)"""

if __name__ == "__main__":
    print("Compile")